chain(ucdavis_cctv, [
    cctv_driver,
    feature_extr%,
    %lightweight_analytics,
    %alarm_driver, 
    %wan_optimiser,
    %storage,
    %video_analytics
   ]).

   service(cctv_driver, 2,  0.5, [ video1 ], or(prop(anti_tampering), prop(access_control))).
   service(feature_extr, 5, 2, [], and(prop(iot_data_encryption), and(prop(anti_tampering), or(prop(obfuscated_storage), prop(encrypted_storage))))).
   %service(lightweight_analytics, 10,  2, [], and(prop(access_control), or(prop(obfuscated_storage), prop(encrypted_storage)))).
   %service(alarm_driver, 2,  0.5, [alarm1 ], list([access_control, host_IDS])).
   %service(wan_optimiser, 5, 5, [], list([pki, firewall, host_IDS])).
   %service(storage, 10, 10, [], list([backup, pki])).
   %service(video_analytics, 40, 16, [], and(prop(resource_monitoring), or(prop(obfuscated_storage), prop(encrypted_storage)))).

   flow(cctv_driver, feature_extr, 20).
   %flow(feature_extr, lightweight_analytics, 8).
   %flow(lightweight_analytics, alarm_driver, .5).
   %flow(feature_extr, wan_optimiser, 20).
   %flow(wan_optimiser, storage, 15). 
   %flow(storage, video_analytics, 10).
   %flow(video_analytics, lightweight_analytics, 0.1).
   
%, lightweight_analytics, alarm_driver
   maxLatency([cctv_driver, feature_extr], 150).

